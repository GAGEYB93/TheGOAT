// React App entry point
console.log('App loaded');